# **Simple Banking Management System in Python using Django Framework **

==============================================================================================
## **Origianl Version Information**
- **Developed by:** Maksudul Haque
- **Download From:** [https://codeastro.com/simple-banking-system-in-python-django-with-source-code//](https://codeastro.com)
==============================================================================================
## **Modified Version Information**
- **Modified by:** oretnom23
- **Download From:** [https://sourcecodester.com/python-django-simple-banking-management-system-source-code/](https://sourcecodester.com)
==============================================================================================


==============================================================================================
## **Admin Access**
- **Email:** admin@mail.com
- **Password:** admin123
==============================================================================================

============================================================================
**Instructions**
- Install the Requirements: pip install -r requirements.txt
- python manage.py migrate
- And finally, run the application: python manage.py runserver
============================================================================
